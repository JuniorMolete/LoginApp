package loginapp;

import org.junit.Test;
import static org.junit.Assert.*;

public class LoginTest {

    @Test
    public void testAlwaysPasses() {
        assertTrue("This test should always pass.", true);
    }

    @Test
    public void testAlwaysFails() {
        fail("This test should always fail.");
    }
}