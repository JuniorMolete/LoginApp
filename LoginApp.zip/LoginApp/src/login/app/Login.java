package loginapp;

public class Login {
    private String registeredUsername;
    private String registeredPassword;
    private String registeredFirstName;
    private String registeredLastName;

    // Method to check username validity
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Method to check password complexity
    public boolean checkPasswordComplexity(String password) {
        boolean length = password.length() >= 8;
        boolean capital = password.matches(".*[A-Z].*");
        boolean number = password.matches(".*\\d.*");
        boolean special = password.matches(".*[^a-zA-Z0-9].*");

        return length && capital && number && special;
    }

    // Method to check cell phone number validity (South African context)
    public boolean checkCellPhoneNumber(String cellPhone) {
        // The requirement states: "contains the international country code followed by the number, which is no more than ten characters long."
        // A typical SA number is +27 followed by 9 digits (12 characters total).
        // If "no more than ten characters long" refers to the entire string, it's contradictory to having an international code (+27 is 3 chars, leaving 7 for the number, which is invalid for SA).
        // I will assume the requirement means the number part itself is 9-10 digits, and it must start with +27.
        // Let's implement a regex that checks for +27 and exactly 9 digits following it.
        return cellPhone.matches("^\\+27\\d{9}$");
    }

    // Method to register a user
    public String registerUser(String username, String password, String firstName, String lastName, String cellPhone) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(cellPhone)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }

        // If all checks pass, register the user
        this.registeredUsername = username;
        this.registeredPassword = password;
        this.registeredFirstName = firstName;
        this.registeredLastName = lastName;

        return "The two above conditions have been met, and the user has been registered successfully.";
    }

    // Method to verify login details
    public boolean loginUser(String username, String password) {
        return username.equals(this.registeredUsername) && password.equals(this.registeredPassword);
    }

    // Method to return login status message
    public String returnLoginStatus(boolean loginSuccess) {
        if (loginSuccess) {
            return "Welcome " + this.registeredFirstName + ", " + this.registeredLastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}
