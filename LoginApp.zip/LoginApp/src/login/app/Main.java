package login.app;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login;
        login = new Login();

        System.out.println("--- User Registration ---");
        System.out.print("Enter First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Enter Last Name: ");
        String lastName = scanner.nextLine();
        System.out.print("Enter Username: ");
        String username = scanner.nextLine();
        System.out.print("Enter Password: ");
        String password = scanner.nextLine();
        System.out.print("Enter Cell Phone Number (e.g., +27123456789): ");
        String cellPhone = scanner.nextLine();

        // Register the user
        String registrationMessage = login.registerUser(username, password, firstName, lastName, cellPhone);
        System.out.println(registrationMessage);

        // If registration was successful, proceed to login
        if (registrationMessage.contains("successfully")) {
            System.out.println("\n--- User Login ---");
            System.out.print("Enter Username: ");
            String loginUsername = scanner.nextLine();
            System.out.print("Enter Password: ");
            String loginPassword = scanner.nextLine();

            // Verify login
            boolean loginSuccess = login.loginUser(loginUsername, loginPassword);
            String loginStatusMessage = login.returnLoginStatus(loginSuccess);
            System.out.println(loginStatusMessage);
        }

        scanner.close();
    }
}
